import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class GroupsReport {

    private static class DeptStudent {
        int id;
        String firstName;
        String lastName;
    }

    private static class CourseStudent {
        int id;
        int grade1;
        int grade2;
    }

    public static void main(String[] args) {
        String csFile = "CS.txt";
        String hedvaFile = "hedva.txt";
        String reportFile = "report.txt";

        try (BufferedReader csReader = new BufferedReader(new FileReader(csFile));
             BufferedReader hedvaReader = new BufferedReader(new FileReader(hedvaFile));
             PrintWriter reportWriter = new PrintWriter(new FileWriter(reportFile))) {

            DeptStudent csStudent = readDeptStudent(csReader);
            CourseStudent courseStudent = readCourseStudent(hedvaReader);

            while (csStudent != null && courseStudent != null) {
                if (csStudent.id == courseStudent.id) {
                    int avg = (courseStudent.grade1 + courseStudent.grade2) / 2;
                    reportWriter.println(csStudent.id + " "
                            + csStudent.firstName + " "
                            + csStudent.lastName + " "
                            + avg);

                    csStudent = readDeptStudent(csReader);
                    courseStudent = readCourseStudent(hedvaReader);

                } else if (csStudent.id < courseStudent.id) {
                    csStudent = readDeptStudent(csReader);
                } else {
                    courseStudent = readCourseStudent(hedvaReader);
                }
            }

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static DeptStudent readDeptStudent(BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split("\s+");
            if (parts.length != 3) continue;

            DeptStudent s = new DeptStudent();
            s.firstName = parts[0];
            s.lastName = parts[1];
            s.id = Integer.parseInt(parts[2]);
            return s;
        }
        return null;
    }

    private static CourseStudent readCourseStudent(BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split("\s+");
            if (parts.length != 3) continue;

            CourseStudent s = new CourseStudent();
            s.id = Integer.parseInt(parts[0]);
            s.grade1 = Integer.parseInt(parts[1]);
            s.grade2 = Integer.parseInt(parts[2]);
            return s;
        }
        return null;
    }
}
